

void foo() { }
