
extern void bar();
extern void baz();

void foo() {
    bar();
    baz();
}
