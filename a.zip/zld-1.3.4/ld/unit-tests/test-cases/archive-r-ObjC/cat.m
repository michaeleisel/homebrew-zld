#include <Foundation/Foundation.h>

@interface NSObject(Cat)
@end

@implementation NSObject(Cat)
@end

@interface NSObject(Dog)
@end

@implementation NSObject(Dog)
@end

void mycatfunc() {}

