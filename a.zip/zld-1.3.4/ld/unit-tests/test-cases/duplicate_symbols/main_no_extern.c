/*
This file contains symbols that are duplicated in another file,
but does not reference anything that would pull in the duplicates.
*/

void a() {
}

void b() {
}

int main() {
}
