#include <stdio.h>

int mymain()
{
	fprintf(stdout, "hello mymain\n");
	return 0;
}