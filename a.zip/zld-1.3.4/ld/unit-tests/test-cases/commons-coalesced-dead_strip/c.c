
const float bar = 1.0;

