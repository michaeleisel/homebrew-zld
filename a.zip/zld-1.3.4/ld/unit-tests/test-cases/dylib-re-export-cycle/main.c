extern void unfindable();

int main() {
   unfindable();
   return 0;
}
