const char* kBar = "hello";
const char* kBar2 = "there";
