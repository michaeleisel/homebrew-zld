


void bar()
{
}

#if BAR_EXTRA
void bar_extra()
{
}
#endif

