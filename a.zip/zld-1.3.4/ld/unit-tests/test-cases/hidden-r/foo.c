void __attribute__((weak,visibility("hidden"))) my_weak()
{
}

int __attribute__((visibility("hidden"))) my_tent;
