
void foo() { }

extern void bar();

void deadwood()
{
	bar();
}

