
extern void foo();

int baz()
{
	return 0;
}

int main()
{
	foo();
	return 0;
}

