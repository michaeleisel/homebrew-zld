     
char *gS = (void *)0;

void LibInit(void)
{
}
  

void OutputString(char *String)
{  
	gS = String;
}

