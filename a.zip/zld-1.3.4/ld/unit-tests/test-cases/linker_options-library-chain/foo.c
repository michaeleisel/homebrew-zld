
extern void bar();
extern void subbar();

void foo() {
    bar();
    subbar();
}
