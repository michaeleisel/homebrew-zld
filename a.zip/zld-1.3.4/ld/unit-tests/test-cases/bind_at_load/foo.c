
void foo() {}
void foo2() {}
