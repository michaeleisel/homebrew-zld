void baz()
{
}


#include "foo.c"

