int bar3() { return 0; }
