int foo3() { return 1; }
