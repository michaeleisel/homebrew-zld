extern int foo4();
int foo2() {
	return foo4();
}
