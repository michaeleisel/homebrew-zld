#include <stdio.h>

class A {
 public:
  virtual ~A();
  void foo() { printf ("Hi\n"); }
};
