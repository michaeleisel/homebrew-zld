#include "a12.h"

enum E e[1000];
void foo(void)
{
  e[1] = ONE;
}

