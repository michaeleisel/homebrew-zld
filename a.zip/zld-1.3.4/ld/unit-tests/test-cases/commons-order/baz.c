int fff_common;
int iii_common[4];
int ttt_common;
