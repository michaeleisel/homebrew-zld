int bar2() { return 0; }

__attribute__((constructor))
void bar2_init() { }
