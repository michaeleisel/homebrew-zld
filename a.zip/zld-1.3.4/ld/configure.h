
#define SUPPORT_ARCH_i386  1
#define SUPPORT_ARCH_x86_64  1
#define SUPPORT_ARCH_x86_64h  1
#define SUPPORT_ARCH_armv6  1
#define SUPPORT_ARCH_armv7  1
#define SUPPORT_ARCH_armv7s  1
#define SUPPORT_ARCH_armv7m  1
#define SUPPORT_ARCH_armv7k  1
#define SUPPORT_ARCH_arm64  1
#define ALL_SUPPORTED_ARCHS  "i386 x86_64 x86_64h armv6 armv7 armv7s armv7m armv7k arm64"
#define BITCODE_XAR_VERSION "1.0"
#define LD64_VERSION_NUM 0
#define LD_PAGE_SIZE 0x1000

