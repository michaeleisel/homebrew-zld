//
//  Tweaks.hpp
//  ld
//
//  Created by Michael Eisel on 2/19/20.
//  Copyright © 2020 Apple Inc. All rights reserved.
//

#ifndef Tweaks_hpp
#define Tweaks_hpp

#include <stdio.h>

namespace Tweaks {
    bool reproEnabled();
}

#endif /* Tweaks_hpp */
